<?php

define('DB_HOST', 'vvv.test:3306');

define('DB_USER', 'external');
define('DB_PASSWORD', 'external');


