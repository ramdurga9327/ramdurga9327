---
name: Support/Question
about: Having Trouble? Unsure of how something works? Don't spend all day trying to debug it, we can help!
title: 'Q: '
labels: 'type:support, type:question'
assignees: ''

---

<!-- Tell us what's happening, include as much detail as you can, and include full logs if you're having troubles
if needed, ping someone on slack with a link to the issue.

If you've given up and gone elsewhere, report it anyway and we can work to make sure it never happens again.

Thank again for using VVV, and helping out!! -->
